
document.write('<div class="menuGroup">');
document.write('<p class="menu_header">Logback project</p>');
document.write('<p class="menu"><a href="' + prefix + 'index.html">Introduction</a></p>');
document.write('<p class="menu"><a href="' + prefix + 'download.html">Download</a></p>');
document.write('<p class="menu"><a href="' + prefix + 'documentation.html">Documentation</a></p>');
document.write('<p class="menu"><a href="' + prefix + 'license.html">License</a></p>');
document.write('<p class="menu"><a href="' + prefix + 'news.html">News</a></p>');

document.write('<p class="menu_header">Support</p>');
document.write('<p class="menu"><a href="' + prefix + 'mailinglist.html">Mailing Lists</a></p>');
document.write('<p class="menu"><a href="' + prefix + 'bugreport.html">Bug Report</a></p>');
document.write('<p class="menu"><a href="http://github.com/qos-ch/logback">Source Repository</a></p>');
document.write('<p class="menu"><a href="' + prefix + 'volunteer.html">Call for volunteers</a>');
document.write('<p class="menu"><a href="http://www.qos.ch/shop/products/professionalSupport">Support offerings</a>');

//document.write('<p class="menu"><a href="http://www.qos.ch/shop/products/training">Training</a>');

document.write('<p class="menu_header">Sister projects</p>');
document.write('<p class="menu"><a href="http://audit.qos.ch/">Logback-audit</a>');

document.write('<p class="menu_header">Online Tools</p>');
document.write('<p class="menu"><a href="https://logback.qos.ch/translator/">log4j.properties Translator</a>');
document.write('<p class="menu"><a href="https://logback.qos.ch/translator/asGroovy.html">logback.XML to Groovy</a>');

document.write('</p>');
document.write('</div>');

document.write('<p>&nbsp;</p>');

document.write('<div class="pub">');
document.write('    <a href="http://twitter.com/qos_ch" style="">');
document.write('      <img alt="Follow @qos_ch" src="' + prefix + 'images/follow_us.png" />');
document.write('    </a>');
document.write('</div>');

document.write('<p>&nbsp;</p>');
document.write('<div class="pub"><img src="https://travis-ci.org/qos-ch/logback.svg?branch=master"/></div>');


//document.write('<div class="jobadd"><p><a href="'+prefix +'job.html">Your career<br/>@QOS.ch</a></p></div>');