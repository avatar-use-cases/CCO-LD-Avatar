This directory contains the the calculator example. It shows how Actions can 
collaborate in order to accomplish a simple computation.

For further information, please refer to 

  http://logback.qos.ch/manual/onJoran.html#calculator

